<?php
/**
 * Created by JetBrains PhpStorm.
 * User: pascal
 * Date: 05.07.12
 * Time: 21:43
 * To change this template use File | Settings | File Templates.
 */

$config["db"] = array(
                        "url" => "localhost",
                        "user" => "root",
                        "password" => "",
                        "database" => "tetris"
                    );

$_SESSION["config"] = $config;